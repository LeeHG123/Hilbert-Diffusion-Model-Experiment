from .ddpm import Model
from .fno import FNO, FNO2
from .unet_mnist import Unet